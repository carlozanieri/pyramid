# Python Pyramid Test App (Public)

This is a **public** python pyramid test app used for testing.

## Configurations needed for your testing
```
"Runtime": "python3",
"BuildCommand": "python setup.py develop",
"StartCommand": "python runapp.py",
"Port": "8000"
```